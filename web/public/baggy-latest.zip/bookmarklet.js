window.baggy = new Baggy();
window.baggy.start();